class Config(object):
	hostname = "smartshare-experiments.chpryfodqoop.us-east-1.rds.amazonaws.com"
	username = "llom2600"
	password = "S0v1ndiv!#!"
	database = "sr1"
	charset = "utf8mb4"
