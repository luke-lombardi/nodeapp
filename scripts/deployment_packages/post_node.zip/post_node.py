'''
    endpoint: /fyb/postNode
    method: POST
    format: application/json

    description:
        Updates a nodes metadata. Used for moving nodes, such as people.
        This node_id can then be added to the 'tracked' node list.
'''

import redis
import json
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)


DEFAULT_NODE_TTL = 3600


def is_cache_connected(rds):
    try:
        response = rds.client_list()
    except redis.ConnectionError:
        return False
    return True


def connect_to_cache():
    rds = redis.StrictRedis(host='redis-11771.c10.us-east-1-4.ec2.cloud.redislabs.com', password='3VyLUrhKv8BzUWtZKtKoIFdqlMk6TVOQ', port=11771, db=0, socket_connect_timeout=5)

    connected = is_cache_connected(rds)
    if connected:
        logging.info('Connection successful.')
        return rds
    else:
        logging.info('Could not connect to redis cache.')
        return None


def update_node(rds, node_id, node_data):
    current_ttl = rds.ttl(node_id)
    logging.info('Node %s has %d seconds to live.', node_id, current_ttl)
    rds.setex(name=node_id, value=json.dumps(node_data), time=DEFAULT_NODE_TTL)


def lambda_handler(event, context):
    rds = connect_to_cache()
    
    if not rds:
        return
    
    node_id = event.get('node_id', 0)
    node_data = event.get('node_data', {})
    if node_data:
        update_node(rds, node_id, node_data)

    logging.info(json.loads(rds.get(node_id)))
    return json.dumps(json.loads(rds.get(node_id)))


def run():
    test_event = {
        "node_id": 12345,
        "node_data": {
            "title": "demos for sale",
            "description": "its me mario",
            "lat": 43.13232,
            "lng": 43.333,
        }
    }
    
    test_context = {

    }

    response = lambda_handler(test_event, test_context)
    print(response)

    
    

if __name__ == '__main__':run()